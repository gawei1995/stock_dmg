import assert from "node:assert/strict";
import test from "node:test";
import {
  buildFxGraph,
  findConversionRate,
  findHkdPerUsd,
  inferInstrumentType,
  normalizeCandles,
  normalizePortfolio,
  normalizeTimestamp,
  selectQuoteMark,
} from "../src/data/normalize.mjs";

test("normalizes account positions, quotes, FX, weights, and exposure", () => {
  const result = normalizePortfolio({
    positions: {
      list: [
        {
          stock_info: [
            {
              symbol: "AAPL.US",
              symbol_name: "Apple",
              quantity: "10",
              available_quantity: "10",
              currency: "USD",
              cost_price: "100",
              market: "US",
            },
          ],
        },
      ],
    },
    balances: [
      {
        currency: "HKD",
        net_assets: "20000",
        total_cash: "1000",
        buy_power: "5000",
        risk_level: "0",
        cash_infos: [],
      },
    ],
    quotes: [{ symbol: "AAPL.US", last_done: "200", prev_close: "190" }],
    exchangeRates: {
      exchanges: [
        { from_currency: "USD", to_currency: "HKD", rate: 8 },
      ],
    },
  });

  assert.equal(result.positions.length, 1);
  assert.equal(result.positions[0].marketValueBase, 16000);
  assert.equal(result.positions[0].weight, 80);
  assert.equal(result.positions[0].tvSymbol, "NASDAQ:AAPL");
  assert.equal(result.groupExposure["消费科技"], 80);
  assert.equal(result.orderWrite, false);
});

test("missing Longbridge account numbers stay null and valuation completeness fails closed", () => {
  const result = normalizePortfolio({
    positions: { list: [] },
    balances: [{
      currency: "USD",
      net_assets: "1000",
      cash_infos: [{ currency: "USD" }],
    }],
    quotes: [],
    exchangeRates: [],
  });

  assert.equal(result.account.netAssets, 1000);
  assert.equal(result.account.totalCash, null);
  assert.equal(result.account.buyPower, null);
  assert.equal(result.account.initMargin, null);
  assert.equal(result.account.maintenanceMargin, null);
  assert.equal(result.account.marginCall, null);
  assert.equal(result.account.cashInfos[0].availableCash, null);
  assert.equal(result.account.valuationComplete, false);
  assert.equal(result.dataQuality.valuationComplete, false);
  assert.equal(result.status, "degraded");
  assert.ok(result.account.missingFields.includes("total_cash"));
});

test("derives HKD per USD from an inverse HKD/USD response", () => {
  const rate = findHkdPerUsd({
    exchanges: [
      { from_currency: "HKD", to_currency: "USD", rate: 0.12755 },
    ],
  });
  assert.ok(Math.abs(rate - 7.84006272) < 0.00001);
});

test("uses the official USD/HKD direction without inversion", () => {
  const rate = findHkdPerUsd({
    exchanges: [
      { from_currency: "USD", to_currency: "HKD", rate: 7.79 },
    ],
  });
  assert.equal(rate, 7.79);
});

test("aggregates the same symbol across Longbridge position channels", () => {
  const result = normalizePortfolio({
    positions: { list: [
      { stock_info: [{ symbol: "AAPL.US", quantity: "2", available_quantity: "2", currency: "USD", cost_price: "100", market: "US" }] },
      { stock_info: [{ symbol: "AAPL.US", quantity: "3", available_quantity: "1", currency: "USD", cost_price: "200", market: "US" }] },
    ] },
    balances: [{ currency: "HKD", net_assets: "10000", total_cash: "1000" }],
    quotes: [{ symbol: "AAPL.US", last_done: "250", prev_close: "240" }],
    exchangeRates: { exchanges: [{ from_currency: "USD", to_currency: "HKD", rate: 8 }] },
  });
  assert.equal(result.positions.length, 1);
  assert.equal(result.positions[0].quantity, 5);
  assert.equal(result.positions[0].availableQuantity, 3);
  assert.equal(result.positions[0].costPrice, 160);
});

test("missing cost price never becomes zero or an invented full-market-value profit", () => {
  const result = normalizePortfolio({
    positions: { list: [{ stock_info: [{
      symbol: "AAPL.US",
      quantity: "2",
      available_quantity: "2",
      currency: "USD",
      market: "US",
    }] }] },
    balances: [{ currency: "USD", net_assets: "1000", total_cash: "500" }],
    quotes: [{
      symbol: "AAPL.US",
      last_done: "250",
      prev_close: "240",
      timestamp: "1767225600",
    }],
    exchangeRates: [],
  });

  const position = result.positions[0];
  assert.equal(position.marketValueBase, 500);
  assert.equal(position.weight, 50);
  assert.equal(position.costPrice, null);
  assert.equal(position.pnlBase, null);
  assert.equal(position.regularPnlBase, null);
  assert.equal(position.pnlPercent, null);
  assert.equal(position.costBasisStatus, "missing");
  assert.match(position.costBasisLimitation, /成本价.*盈亏保持为空/);
  assert.equal(result.dataQuality.costBasisComplete, false);
  assert.equal(result.dataQuality.missingCostBasisPositionCount, 1);
  assert.deepEqual(result.dataQuality.missingCostBasisSymbols, ["AAPL.US"]);
});

test("one missing-cost channel invalidates the aggregate cost basis without hiding market value", () => {
  const result = normalizePortfolio({
    positions: { list: [
      { stock_info: [{ symbol: "AAPL.US", quantity: "2", currency: "USD", cost_price: "100", market: "US" }] },
      { stock_info: [{ symbol: "AAPL.US", quantity: "3", currency: "USD", market: "US" }] },
    ] },
    balances: [{ currency: "USD", net_assets: "1000", total_cash: "0" }],
    quotes: [{ symbol: "AAPL.US", last_done: "200", timestamp: "1767225600" }],
    exchangeRates: [],
  });

  assert.equal(result.positions[0].quantity, 5);
  assert.equal(result.positions[0].marketValueBase, 1000);
  assert.equal(result.positions[0].costPrice, null);
  assert.equal(result.positions[0].pnlBase, null);
  assert.equal(result.positions[0].costBasisStatus, "missing");
});

test("USD-only portfolio ignores FX-source failure for valuation completeness", () => {
  const result = normalizePortfolio({
    positions: { list: [{ stock_info: [{
      symbol: "AAPL.US",
      quantity: "2",
      currency: "USD",
      cost_price: "100",
      market: "US",
    }] }] },
    balances: [{
      currency: "USD",
      net_assets: "1000",
      total_cash: "500",
      cash_infos: [{ currency: "USD", available_cash: "500" }],
    }],
    quotes: [{ symbol: "AAPL.US", last_done: "250", timestamp: "1767225600" }],
    exchangeRates: [],
    fxStatus: "unavailable",
    sourceErrors: [
      { tool: "exchange_rate", code: 463, kind: "gateway", message: "failed" },
      { tool: "ecb_reference_rates", kind: "network", message: "offline" },
    ],
  });

  assert.equal(result.status, "live");
  assert.equal(result.dataQuality.valuationComplete, true);
  assert.equal(result.dataQuality.fxStatus, "not_required");
  assert.equal(result.dataQuality.fxRequired, false);
  assert.deepEqual(result.dataQuality.sourceErrors, []);
  assert.equal(result.dataQuality.ignoredFxErrors.length, 2);
});

test("keeps real quantities but degrades valuation when a quote is missing", () => {
  const result = normalizePortfolio({
    positions: { list: [{ stock_info: [{ symbol: "AAPL.US", quantity: "2", currency: "USD", cost_price: "100", market: "US" }] }] },
    balances: [{ currency: "HKD", net_assets: "10000" }],
    quotes: [],
    exchangeRates: { exchanges: [{ from_currency: "USD", to_currency: "HKD", rate: 8 }] },
  });
  assert.equal(result.status, "degraded");
  assert.equal(result.positions[0].quantity, 2);
  assert.equal(result.positions[0].valuationStatus, "unpriced");
  assert.equal(result.positions[0].lastPrice, null);
  assert.equal(result.positions[0].weight, null);
});

test("keeps the native quote when FX is unavailable without inventing a conversion", () => {
  const result = normalizePortfolio({
    positions: { list: [{ stock_info: [{
      symbol: "AAPL.US",
      quantity: "2",
      currency: "USD",
      cost_price: "100",
      market: "US",
    }] }] },
    balances: [{ currency: "HKD", net_assets: "10000" }],
    quotes: [{ symbol: "AAPL.US", last_done: "250", prev_close: "240", timestamp: "1767225600" }],
    exchangeRates: [],
    fxStatus: "unavailable",
    sourceErrors: [{ tool: "exchange_rate", code: 463, kind: "gateway", message: "status error: 463" }],
  });
  assert.equal(result.holdingsStatus, "live");
  assert.equal(result.positions[0].lastPrice, 250);
  assert.equal(result.positions[0].marketValue, 500);
  assert.equal(result.positions[0].marketValueBase, null);
  assert.equal(result.positions[0].weight, null);
  assert.equal(result.positions[0].valuationStatus, "native_only");
  assert.equal(result.dataQuality.fxStatus, "unavailable");
  assert.equal(result.dataQuality.sourceErrors[0].code, 463);
});

test("identifies Longbridge option symbols for the nonlinear-risk guard", () => {
  assert.equal(inferInstrumentType("AAPL250117C250000.US"), "option");
  assert.equal(inferInstrumentType("AAPL.US"), "equity");
});

test("candles are numeric and chronologically sorted", () => {
  const bars = normalizeCandles([
    { timestamp: "2026-01-02T00:00:00Z", open: "2", high: "3", low: "1", close: "2.5" },
    { timestamp: "2026-01-01T00:00:00Z", open: "1", high: "2", low: "0.5", close: "1.5" },
  ]);
  assert.equal(bars[0].close, 1.5);
  assert.equal(bars[1].close, 2.5);
});

test("Longbridge HK daily midnight timestamp maps to its exchange trading date", () => {
  const bars = normalizeCandles({
    symbol: "700.HK",
    candlesticks: [{
      // First item in the official Longbridge Apr 20/21/22/25/26 sequence.
      timestamp: "1650384000",
      open: "364.600",
      high: "368.800",
      low: "361.600",
      close: "362.000",
      volume: "10853604",
      is_closed: true,
    }],
  });
  assert.equal(bars[0].timestamp, "2022-04-19T16:00:00.000Z");
  assert.equal(bars[0].tradeDate, "2022-04-20");
  assert.equal(bars[0].timestampBasis, "provider_exchange_date");
  assert.equal(bars[0].symbol, "700.HK");
  assert.equal(bars[0].market, "HK");
  assert.equal(bars[0].isClosed, true);
});

test("an explicit candle tradeDate takes precedence over timestamp inference", () => {
  const [bar] = normalizeCandles({
    symbol: "700.HK",
    candlesticks: [{
      timestamp: "1650384000",
      trade_date: "2022-04-18",
      open: "348.0",
      high: "349.8",
      low: "340.0",
      close: "344.6",
    }],
  });
  assert.equal(bar.tradeDate, "2022-04-18");
  assert.equal(bar.timestampBasis, "explicit_trade_date");
});

test("normalizes Longbridge epoch-second timestamps before EMA ordering", () => {
  assert.equal(normalizeTimestamp("1767225600"), "2026-01-01T00:00:00.000Z");
});

test("uses the newest valid extended-hours mark and records its session", () => {
  const mark = selectQuoteMark({
    last_done: "100",
    timestamp: "1767225600",
    post_market_quote: { last_done: "105", timestamp: "1767232800" },
    pre_market_quote: { last_done: "99", timestamp: "1767218400" },
  });
  assert.equal(mark.price, 105);
  assert.equal(mark.session, "post_market");
  assert.equal(mark.timestamp, "2026-01-01T02:00:00.000Z");
});

test("keeps the regular mark beside the latest after-hours mark for formal close snapshots", () => {
  const result = normalizePortfolio({
    positions: { list: [{ stock_info: [{
      symbol: "AAPL.US",
      quantity: "10",
      currency: "USD",
      cost_price: "90",
      market: "US",
    }] }] },
    balances: [{ currency: "USD", net_assets: "1100", total_cash: "100" }],
    quotes: [{
      symbol: "AAPL.US",
      last_done: "100",
      timestamp: "1767225600",
      post_market_quote: { last_done: "105", timestamp: "1767232800" },
    }],
    exchangeRates: [],
  });

  assert.equal(result.positions[0].lastPrice, 105);
  assert.equal(result.positions[0].quoteSession, "post_market");
  assert.equal(result.positions[0].regularLastPrice, 100);
  assert.equal(result.positions[0].regularMarketValueBase, 1000);
  assert.equal(result.regularQuoteAsOf, "2026-01-01T00:00:00.000Z");
});

test("supports current Longbridge extended-hours field names", () => {
  const mark = selectQuoteMark({
    last_done: "100",
    timestamp: "1767225600",
    pre_market: { last_done: "99", timestamp: "1767218400" },
    post_market: { last_done: "105", timestamp: "1767232800" },
    overnight: { last_done: "107", timestamp: "1767243600" },
  });
  assert.equal(mark.price, 107);
  assert.equal(mark.session, "overnight");
  assert.equal(mark.timestamp, "2026-01-01T05:00:00.000Z");
});

test("uses a valid legacy extended-hours mark when a current alias is incomplete", () => {
  const mark = selectQuoteMark({
    last_done: "100",
    timestamp: "1767225600",
    post_market: { timestamp: "1767236400" },
    post_market_quote: { last_done: "106", timestamp: "1767232800" },
  });
  assert.equal(mark.price, 106);
  assert.equal(mark.session, "post_market");
});

test("converts multi-currency holdings through the complete Longbridge FX graph", () => {
  const graph = buildFxGraph({ exchanges: [
    { from_currency: "SGD", to_currency: "USD", rate: 0.75 },
    { from_currency: "USD", to_currency: "HKD", rate: 7.8 },
  ] });
  assert.ok(Math.abs(findConversionRate("SGD", "HKD", graph) - 5.85) < 1e-9);
  const result = normalizePortfolio({
    positions: { list: [{ stock_info: [{ symbol: "D05.SG", quantity: "10", currency: "SGD", cost_price: "90", market: "SG" }] }] },
    balances: [{ currency: "HKD", net_assets: "100000", total_cash: "10000" }],
    quotes: [{ symbol: "D05.SG", last_done: "100", timestamp: "1767225600" }],
    exchangeRates: { exchanges: [
      { from_currency: "SGD", to_currency: "USD", rate: 0.75 },
      { from_currency: "USD", to_currency: "HKD", rate: 7.8 },
    ] },
  });
  assert.equal(result.positions[0].marketValueBase, 5850);
  assert.equal(result.status, "live");
});

test("option valuation requires the real contract multiplier and never assumes 100", () => {
  const base = {
    positions: { list: [{ stock_info: [{ symbol: "AAPL250117C250000.US", quantity: "2", currency: "USD", cost_price: "5", market: "US" }] }] },
    balances: [{ currency: "USD", net_assets: "10000", total_cash: "1000" }],
    exchangeRates: [],
  };
  const unpriced = normalizePortfolio({
    ...base,
    quotes: [{ symbol: "AAPL250117C250000.US", last_done: "6" }],
  });
  assert.equal(unpriced.status, "degraded");
  assert.equal(unpriced.positions[0].marketValueBase, null);

  const priced = normalizePortfolio({
    ...base,
    quotes: [{
      symbol: "AAPL250117C250000.US",
      last_done: "6",
      option_extend: { contract_multiplier: "100" },
    }],
  });
  assert.equal(priced.positions[0].marketValueBase, 1200);
  assert.equal(priced.positions[0].weight, 12);
});

test("gross exposure preserves offsetting long and short legs across channels", () => {
  const result = normalizePortfolio({
    positions: { list: [
      { account_channel: "cash", stock_info: [{ symbol: "AAPL.US", quantity: "10", currency: "USD", cost_price: "90", market: "US" }] },
      { account_channel: "margin", stock_info: [{ symbol: "AAPL.US", quantity: "-4", currency: "USD", cost_price: "110", market: "US" }] },
    ] },
    balances: [{ currency: "USD", net_assets: "10000" }],
    quotes: [{ symbol: "AAPL.US", last_done: "100", timestamp: "1767225600" }],
    exchangeRates: [],
  });
  const position = result.positions[0];
  assert.equal(position.quantity, 6);
  assert.equal(position.grossQuantity, 14);
  assert.equal(position.netWeight, 6);
  assert.ok(Math.abs(position.weight - 14) < 1e-9);
  assert.equal(position.hasOffsettingLegs, true);
});
